ALTER TABLE `event`
	ADD CONSTRAINT `867d9fe5a7952bd7cd4001266ef8a9` FOREIGN KEY(`event_id`) REFERENCES `event_banners`(`event_banner_id`) ON DELETE CASCADE;
