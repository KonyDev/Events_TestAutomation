ALTER TABLE `event_metrics`
	MODIFY `action` VARCHAR(32);
