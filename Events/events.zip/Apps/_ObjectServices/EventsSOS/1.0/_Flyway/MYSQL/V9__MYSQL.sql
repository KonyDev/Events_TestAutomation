ALTER TABLE `users`
	ADD `first_name` VARCHAR(256),
	ADD `last_name` VARCHAR(256),
	ADD `login_mode` BIGINT,
	ADD `mail` VARCHAR(128),
	ADD `profile` VARCHAR(256);
