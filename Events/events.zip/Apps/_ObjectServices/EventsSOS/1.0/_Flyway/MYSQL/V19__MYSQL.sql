ALTER TABLE `event_registration`
	ADD CONSTRAINT `39c8dbd64b89ec58e7cdbc95985eb4` FOREIGN KEY(`event_id`) REFERENCES `event`(`event_id`) ON DELETE CASCADE;
