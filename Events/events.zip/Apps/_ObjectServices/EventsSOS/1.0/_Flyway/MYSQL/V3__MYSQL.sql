RENAME TABLE `user_details` TO `login_details`;
