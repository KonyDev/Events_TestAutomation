RENAME TABLE `users` TO `user_details`;
