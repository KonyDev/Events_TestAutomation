ALTER TABLE `event_metrics`
	DROP COLUMN `user_id`;
